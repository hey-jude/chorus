/*-------------------------------------------------------------------------
 *
 * perfmon.h
 *
 * Copyright (c) 2005-2009, Greenplum inc
 *
 * $Id: //cdb2/private/cpedrotti/main/cdb-pg/src/include/postmaster/permfon.h#1 $
 *
 *-------------------------------------------------------------------------
 */
#ifndef PERFMON_H
#define PERFMON_H

extern int perfmon_start(void);

#endif   /* PERFMON_H */
