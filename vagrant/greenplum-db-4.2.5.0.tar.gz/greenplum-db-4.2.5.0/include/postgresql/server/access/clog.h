/*
 * clog.h
 *
 * PostgreSQL transaction-commit-log manager
 *
 * Portions Copyright (c) 1996-2009, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * $PostgreSQL: pgsql/src/include/access/clog.h,v 1.18 2006/11/05 22:42:09 tgl Exp $
 */
#ifndef CLOG_H
#define CLOG_H

#include "access/xlog.h"

/*
 * Possible transaction statuses --- note that all-zeroes is the initial
 * state.
 *
 * A "subcommitted" transaction is a committed subtransaction whose parent
 * hasn't committed or aborted yet.
 */
typedef int XidStatus;

#define TRANSACTION_STATUS_IN_PROGRESS		0x00
#define TRANSACTION_STATUS_COMMITTED		0x01
#define TRANSACTION_STATUS_ABORTED			0x02
#define TRANSACTION_STATUS_SUB_COMMITTED	0x03


/* Number of SLRU buffers to use for clog */
#define NUM_CLOG_BUFFERS	8


extern void TransactionIdSetStatus(TransactionId xid, XidStatus status);

extern XidStatus TransactionIdGetStatus(TransactionId xid);
extern XidStatus InRecoveryTransactionIdGetStatus(TransactionId xid, bool *valid);

extern char *XidStatus_Name(XidStatus status);

extern Size CLOGShmemSize(void);
extern void CLOGShmemInit(void);
extern void BootStrapCLOG(void);
extern void StartupCLOG(void);
extern void ShutdownCLOG(void);
extern void CheckPointCLOG(void);
extern void ExtendCLOG(TransactionId newestXact);
extern void TruncateCLOG(TransactionId oldestXact);
extern bool CLOGScanForPrevStatus(
	TransactionId	*indexXid,
	XidStatus		*status);
extern bool CLOGTransactionIsOld(TransactionId xid);

/* XLOG stuff */
#define CLOG_ZEROPAGE		0x00
#define CLOG_TRUNCATE		0x10

extern void clog_redo(XLogRecPtr beginLoc, XLogRecPtr lsn, XLogRecord *record);
extern void clog_desc(StringInfo buf, XLogRecPtr beginLoc, XLogRecord *record);

#endif   /* CLOG_H */
