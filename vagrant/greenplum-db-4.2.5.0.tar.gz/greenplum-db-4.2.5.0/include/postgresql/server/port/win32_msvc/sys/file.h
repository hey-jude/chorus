/* $PostgreSQL: pgsql/src/include/port/win32_msvc/sys/file.h,v 1.3 2006/10/04 00:30:10 momjian Exp $ */
