/* $PostgreSQL: pgsql/src/include/port/freebsd.h,v 1.16 2006/03/11 04:38:38 momjian Exp $ */
