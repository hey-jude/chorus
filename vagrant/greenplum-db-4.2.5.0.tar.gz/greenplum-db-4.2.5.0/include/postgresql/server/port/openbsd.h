/* $PostgreSQL: pgsql/src/include/port/openbsd.h,v 1.14 2006/03/11 04:38:38 momjian Exp $ */
