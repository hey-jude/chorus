/*--------------------------------------------------------------------
 * segadmin.h
 *
 * Prototypes for segadmin.c functions. Most of these are actually in
 * builtins.h.
 *--------------------------------------------------------------------
 */
#ifndef SEGADMIN_H
#define SEGADMIN_H

extern int16 MyDbid(void);

#endif /* SEGADMIN_H */
