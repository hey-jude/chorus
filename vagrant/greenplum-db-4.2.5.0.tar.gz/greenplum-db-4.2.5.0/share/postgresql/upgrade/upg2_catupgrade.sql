--
-- Catalog Upgrade Script
--
--   This script has 3 parts
--   1. Pre-upgrade setup
--   2. Execute the main upgrade script
--   3. Post-upgrade cleanup and commit
--
--   In pre-upgrade, we
--     1. set psql to "stop on error"
--     2. begin txn for the whole upgrade
--     3. create helper function
--
--  In the main execution script, it'll perform DDL/DML to transform the catalog
--  to the next version of the catalog
--
--  In the post-upgrade step, we
--     1. add PIN dependency to newly created catalog objects
--     2. drop the helper functions
--     3. commit the txn


-------------------------------------
-- Pre upgrade
--   set plsql to "stop on error"
--   begin txn
--   create temp helper routines
------------------------------------
\set ON_ERROR_STOP ON

-- We need plpgsql
create language plpgsql;

-- No need to run in a transaction, we always rollback thoroughly, plus, the
-- pg_compression table needs to be visible so that we can add rows to it.

-- Use this pl/pgsql function to execute DML on cat tab on all segs
create or replace function pg_catalog.catDML(stmt text) returns int as $$
begin
  execute stmt;
  return 1;
end;
$$ language 'plpgsql';

-- Use this pl/pgsql function to add PIn dependency of the newly created procedure
create or replace function pg_catalog.addProcPIN(classoid oid, procid oid) returns int as $$
begin
  INSERT INTO pg_catalog.pg_depend values(0,0,0, classoid, procid, 0, 'p');
  PERFORM pg_catalog.catDML('INSERT INTO pg_catalog.pg_depend values(0,0,0, '||classoid||', '||procid||', 0, ''p'')') from gp_dist_random('gp_id');
  return 1;
end;
$$ language 'plpgsql';

-- Use this pl/pgsql function to remove the default table privilege
create or replace function pg_catalog.removeDefaultPrivilege(tablenm text) returns int as $$
declare
  username name;
  stmt text;
begin
  select rolname into username from pg_authid where oid = 10;
  stmt := 'revoke all on table pg_catalog.' || tablenm || ' from ' || quote_ident(username);
  execute stmt;
  return 1;
end;
$$ language 'plpgsql';

-------------------------------------
-- Execute the main upgrade script
-------------------------------------
\set upg2script `echo $GPHOME/share/postgresql/upgrade/upg2_catupgrade_42.sql`
\i :upg2script

-------------------------------------
-- Blow away the gp_toolkit schema
-------------------------------------
DROP SCHEMA if exists gp_toolkit cascade;
CREATE SCHEMA gp_toolkit ;


----------------------------------------
-- Post upgrade step
--   drop catalog dependency
--   add PIN dependency to newly created catalog objects
--   drop temp helper routine
--   commit the txn
----------------------------------------
DELETE FROM pg_catalog.pg_depend WHERE classid<10000 and objid <10000 and classid != 0;
select pg_catalog.catDML(
'DELETE FROM pg_catalog.pg_depend WHERE classid<10000 and objid <10000 and classid != 0')
from gp_dist_random('gp_id');

INSERT INTO pg_catalog.pg_depend SELECT 0,0,0, tableoid,oid,0, 'p' FROM pg_catalog.pg_proc
        where (tableoid,oid) not in (Select refclassid, refobjid from pg_catalog.pg_depend where deptype = 'p')
          and oid < 10000;
select pg_catalog.catDML(
'INSERT INTO pg_catalog.pg_depend SELECT 0,0,0, tableoid,oid,0, ''p'' FROM pg_catalog.pg_proc
        where (tableoid,oid) not in (Select refclassid, refobjid from pg_catalog.pg_depend where deptype = ''p'')
          and oid < 10000')
from gp_dist_random('gp_id');

INSERT INTO pg_catalog.pg_depend SELECT 0,0,0, tableoid,oid,0, 'p' FROM pg_catalog.pg_class
        where (tableoid,oid) not in (Select refclassid, refobjid from pg_catalog.pg_depend where deptype = 'p')
          and oid < 10000;
select pg_catalog.catDML(
'INSERT INTO pg_catalog.pg_depend SELECT 0,0,0, tableoid,oid,0, ''p'' FROM pg_catalog.pg_class
        where (tableoid,oid) not in (Select refclassid, refobjid from pg_catalog.pg_depend where deptype = ''p'')
          and oid < 10000')
from gp_dist_random('gp_id');

INSERT INTO pg_catalog.pg_depend SELECT 0,0,0, tableoid,oid,0, 'p' FROM pg_catalog.pg_type
        where (tableoid,oid) not in (Select refclassid, refobjid from pg_catalog.pg_depend where deptype = 'p')
          and oid < 10000;
select pg_catalog.catDML(
'INSERT INTO pg_catalog.pg_depend SELECT 0,0,0, tableoid,oid,0, ''p'' FROM pg_catalog.pg_type
        where (tableoid,oid) not in (Select refclassid, refobjid from pg_catalog.pg_depend where deptype = ''p'')
          and oid < 10000')
from gp_dist_random('gp_id');

drop function pg_catalog.catDML(stmt text);
drop function pg_catalog.addProcPIN(classoid oid, procid oid);
drop function pg_catalog.removeDefaultPrivilege(tablenm text);
\unset ON_ERROR_STOP
