-- Adjust this setting to control where the objects get created.

CREATE SCHEMA workfile;
SET search_path = workfile;

BEGIN;

-- Register the functions.
     
CREATE OR REPLACE FUNCTION gp_workfile_entries()
RETURNS SETOF record
AS '$libdir/gp_workfile_mgr', 'gp_workfile_mgr_cache_entries'
LANGUAGE C IMMUTABLE;

CREATE VIEW gp_workfile_entries AS
WITH all_entries AS (
   SELECT C.*
          FROM gp_toolkit.__gp_localid, workfile.gp_workfile_entries() AS C (
            segid int, 
            path text, 
            hash int, 
            size bigint, 
            utility int, 
            state int, 
            workmem int,
            optype text, 
            slice int,
            sessionid int, 
            commandid int,
            query_start timestamptz
          )
    UNION ALL
    SELECT C.*
          FROM gp_toolkit.__gp_masterid, workfile.gp_workfile_entries() AS C (
            segid int, 
            path text, 
            hash int, 
            size bigint, 
            utility int, 
            state int, 
            workmem int,
            optype text, 
            slice int,
            sessionid int, 
            commandid int,
            query_start timestamptz
          ))
SELECT S.datname, 
       (CASE WHEN (C.state = 1) THEN S.procpid ELSE NULL END) AS procpid, 
       C.sessionid as sess_id, 
       C.commandid as command_cnt,
       S.usename, 
       (CASE WHEN (C.state = 1) THEN S.current_query ELSE NULL END) as current_query, 
       C.segid, 
       C.slice, 
       C.optype, 
       C.workmem, 
       C.size, 
       C.path as directory, 
       (CASE WHEN (C.state = 1) THEN 'RUNNING' WHEN (C.state = 2) THEN 'CACHED' WHEN (C.state = 3) THEN 'DELETING' ELSE 'UNKNOWN' END) as state, 
       C.utility
FROM all_entries C LEFT OUTER JOIN 
pg_stat_activity as S
ON C.sessionid = S.sess_id;


CREATE OR REPLACE FUNCTION gp_workfile_cache_clear_f(content int)
    RETURNS SETOF int
AS '$libdir/gp_workfile_mgr', 'gp_workfile_mgr_clear_cache' LANGUAGE C IMMUTABLE;

CREATE FUNCTION gp_workfile_cache_clear_segment(content int)
RETURNS SETOF int
AS
$$
 SELECT C.* FROM gp_toolkit.__gp_localid, workfile.gp_workfile_cache_clear_f($1) as C
 UNION ALL
 SELECT C.* FROM gp_toolkit.__gp_masterid, workfile.gp_workfile_cache_clear_f($1) as C;
$$
LANGUAGE SQL;

CREATE FUNCTION gp_workfile_cache_clear()
RETURNS SETOF int
AS
$$
  SELECT * from workfile.gp_workfile_cache_clear_segment(-2)
$$
LANGUAGE SQL; 

CREATE OR REPLACE FUNCTION gp_workfile_mgr_test(testname text)
RETURNS setof bool
AS '$libdir/gp_workfile_mgr', 'gp_workfile_mgr_test_harness_wrapper' LANGUAGE C IMMUTABLE;

CREATE FUNCTION gp_workfile_mgr_test_allsegs(testname text)
RETURNS SETOF BOOL
AS
$$
 SELECT C.* FROM gp_toolkit.__gp_localid, workfile.gp_workfile_mgr_test($1) as C
 UNION ALL
 SELECT C.* FROM gp_toolkit.__gp_masterid, workfile.gp_workfile_mgr_test($1) as C;
$$
LANGUAGE SQL;

CREATE VIEW gp_workfile_usage_per_segment AS
SELECT gpseg.content AS segid, COALESCE(SUM(wfe.size),0) AS size 
FROM (
	SELECT content 
	FROM gp_segment_configuration 
	WHERE role = 'p') gpseg 
LEFT JOIN workfile.gp_workfile_entries wfe 
ON (gpseg.content = wfe.segid) 
GROUP BY gpseg.content;

CREATE VIEW gp_workfile_usage_per_query AS
SELECT datname, procpid, sess_id, command_cnt, usename, current_query, segid, state, sum(size) AS size 
FROM workfile.gp_workfile_entries
GROUP BY (datname, procpid, sess_id, command_cnt, usename, current_query, segid, state);

COMMIT;
